import { Facility } from '../types';

// Mock function to add distance and ETA to facilities
// In a real app, this would use geolocation API and routing services
export function addDistanceAndETA(facilities: Facility[]): Facility[] {
  // Mock distances and ETAs based on facility type and location
  const mockDistances: Record<string, { distance: number; drivingETA: number; walkingETA: number }> = {
    'fac-1': { distance: 0.5, drivingETA: 2, walkingETA: 10 },
    'fac-2': { distance: 0.7, drivingETA: 3, walkingETA: 14 },
    'fac-3': { distance: 0.4, drivingETA: 2, walkingETA: 8 },
    'fac-4': { distance: 0.6, drivingETA: 3, walkingETA: 12 },
    'fac-5': { distance: 0.8, drivingETA: 3, walkingETA: 16 },
    'fac-6': { distance: 2.1, drivingETA: 7, walkingETA: 42 },
    'fac-7': { distance: 1.4, drivingETA: 5, walkingETA: 28 },
    'fac-8': { distance: 3.8, drivingETA: 12, walkingETA: 76 },
    'fac-9': { distance: 0.6, drivingETA: 3, walkingETA: 12 },
    'fac-10': { distance: 1.8, drivingETA: 6, walkingETA: 36 },
    'fac-11': { distance: 1.9, drivingETA: 6, walkingETA: 38 },
  };

  return facilities.map(facility => ({
    ...facility,
    ...mockDistances[facility.id]
  }));
}

// Format ETA in a human-readable way
export function formatETA(minutes: number): string {
  if (minutes < 60) {
    return `${minutes} min`;
  }
  const hours = Math.floor(minutes / 60);
  const mins = minutes % 60;
  return mins > 0 ? `${hours}h ${mins}m` : `${hours}h`;
}