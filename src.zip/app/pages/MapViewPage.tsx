import { useState, useMemo } from 'react';
import { mockFacilities } from '../data/mockData';
import { Card, CardContent } from '../components/ui/card';
import { Badge } from '../components/ui/badge';
import { Link } from 'react-router';
import { Button } from '../components/ui/button';
import { MapPin, Navigation, Car, PersonStanding } from 'lucide-react';
import { addDistanceAndETA } from '../utils/distanceCalculator';

// Mock coordinates for facilities
const facilityCoordinates: Record<string, [number, number]> = {
  'fac-1': [33.9002, -117.8871], // Chase Gymnasium
  'fac-2': [33.9005, -117.8880], // Soccer Field
  'fac-3': [33.9008, -117.8865], // Tennis Courts
  'fac-4': [33.9000, -117.8875], // Aquatic Center
  'fac-5': [33.9010, -117.8868], // Track & Field
  'fac-6': [33.9174, -117.8571], // La Mirada Regional Park
  'fac-7': [33.8992, -117.8534], // Creek Park
  'fac-8': [33.8456, -117.7857], // Nohl Ranch Park
  'fac-9': [33.9001, -117.8873], // Racquetball Courts
  'fac-10': [33.9120, -117.8590], // Neff Historical Park
  'fac-11': [33.9135, -117.8605], // La Mirada City Gardenhill Park
};

export function MapViewPage() {
  const [selectedFacility, setSelectedFacility] = useState<string | null>(null);
  
  // Add distance and ETA to all facilities
  const facilitiesWithDistance = useMemo(() => addDistanceAndETA(mockFacilities), []);

  return (
    <div className="container mx-auto px-4 py-8 space-y-8">
      <div>
        <h1 className="text-3xl font-bold">Facility Map</h1>
        <p className="text-muted-foreground mt-2">Find facilities near you</p>
      </div>

      <Card>
        <CardContent className="p-6">
          <div className="space-y-4">
            <div className="flex items-center gap-3">
              <div className="size-12 rounded-full bg-primary/10 flex items-center justify-center">
                <Navigation className="size-6 text-primary" />
              </div>
              <div>
                <h3 className="font-semibold text-lg">Location Overview</h3>
                <p className="text-sm text-muted-foreground">
                  Biola University & La Mirada Area
                </p>
              </div>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 py-4">
              <div className="text-center p-4 rounded-lg bg-muted">
                <div className="text-2xl font-bold text-primary">{facilitiesWithDistance.length}</div>
                <div className="text-sm text-muted-foreground">Total Facilities</div>
              </div>
              <div className="text-center p-4 rounded-lg bg-muted">
                <div className="text-2xl font-bold text-primary">
                  {facilitiesWithDistance.filter(f => f.type === 'campus').length}
                </div>
                <div className="text-sm text-muted-foreground">Campus Facilities</div>
              </div>
              <div className="text-center p-4 rounded-lg bg-muted">
                <div className="text-2xl font-bold text-primary">
                  {facilitiesWithDistance.filter(f => f.type === 'park').length}
                </div>
                <div className="text-sm text-muted-foreground">Public Parks</div>
              </div>
            </div>

            <div className="p-4 rounded-lg border-2 border-dashed border-muted-foreground/30">
              <p className="text-sm text-center text-muted-foreground">
                Interactive map view - Click on facilities below to see details
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      <div className="space-y-3">
        <h2 className="text-xl font-semibold">All Facilities</h2>
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {facilitiesWithDistance.map((facility) => {
            const coords = facilityCoordinates[facility.id];
            
            return (
              <Card
                key={facility.id}
                className={`cursor-pointer transition-all hover:shadow-lg ${
                  selectedFacility === facility.id ? 'ring-2 ring-primary' : ''
                }`}
                onClick={() => setSelectedFacility(facility.id)}
              >
                <CardContent className="p-4">
                  <div className="flex items-start justify-between mb-2">
                    <h3 className="font-semibold">{facility.name}</h3>
                    <MapPin className="size-4 text-muted-foreground flex-shrink-0 ml-2" />
                  </div>
                  
                  <Badge variant={facility.type === 'campus' ? 'default' : 'secondary'} className="mb-2">
                    {facility.type === 'campus' ? 'Campus' : 'Public Park'}
                  </Badge>
                  
                  <p className="text-sm text-muted-foreground mb-3">{facility.location}</p>
                  
                  {/* Distance and ETA Information */}
                  {(facility.distance !== undefined || facility.drivingETA !== undefined || facility.walkingETA !== undefined) && (
                    <div className="space-y-1.5 mb-3 text-sm">
                      {facility.distance !== undefined && (
                        <div className="flex items-center justify-between">
                          <span className="text-muted-foreground">Distance:</span>
                          <span className="font-medium">{facility.distance} mi</span>
                        </div>
                      )}
                      {facility.drivingETA !== undefined && (
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-1.5">
                            <Car className="size-3.5 text-blue-600" />
                            <span className="text-muted-foreground">Driving:</span>
                          </div>
                          <span className="font-medium">{facility.drivingETA} min</span>
                        </div>
                      )}
                      {facility.walkingETA !== undefined && (
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-1.5">
                            <PersonStanding className="size-3.5 text-green-600" />
                            <span className="text-muted-foreground">Walking:</span>
                          </div>
                          <span className="font-medium">{facility.walkingETA} min</span>
                        </div>
                      )}
                    </div>
                  )}
                  
                  {coords && (
                    <p className="text-xs text-muted-foreground mb-3 font-mono">
                      📍 {coords[0].toFixed(4)}, {coords[1].toFixed(4)}
                    </p>
                  )}
                  
                  <div className="flex flex-wrap gap-1 mb-3">
                    {facility.sports.slice(0, 3).map((sport) => (
                      <Badge key={sport} variant="outline" className="text-xs">
                        {sport}
                      </Badge>
                    ))}
                    {facility.sports.length > 3 && (
                      <Badge variant="outline" className="text-xs">
                        +{facility.sports.length - 3}
                      </Badge>
                    )}
                  </div>
                  
                  <Link to={`/facility/${facility.id}`}>
                    <Button variant="outline" size="sm" className="w-full">
                      View Details
                    </Button>
                  </Link>
                </CardContent>
              </Card>
            );
          })}
        </div>
      </div>
    </div>
  );
}