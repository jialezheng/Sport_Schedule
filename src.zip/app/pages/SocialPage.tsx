import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { Avatar, AvatarFallback } from '../components/ui/avatar';
import { Badge } from '../components/ui/badge';
import { Button } from '../components/ui/button';
import { Textarea } from '../components/ui/textarea';
import { Heart, MessageCircle, Share2, Calendar, MapPin, Users } from 'lucide-react';
import { mockTimeSlots, mockFacilities } from '../data/mockData';
import { format } from 'date-fns';
import { useState } from 'react';

interface Activity {
  id: string;
  user: string;
  action: string;
  facility: string;
  sport: string;
  time: Date;
  likes: number;
  comments: number;
}

export function SocialPage() {
  const [newPost, setNewPost] = useState('');

  // Generate mock social activities from time slots
  const activities: Activity[] = mockTimeSlots.slice(0, 10).map((slot, index) => {
    const facility = mockFacilities.find(f => f.id === slot.facilityId);
    return {
      id: slot.id,
      user: slot.participants[0]?.name || 'User',
      action: 'joined a session',
      facility: facility?.name || 'Unknown',
      sport: slot.sport,
      time: new Date(Date.now() - index * 3600000),
      likes: Math.floor(Math.random() * 20),
      comments: Math.floor(Math.random() * 10),
    };
  });

  return (
    <div className="container mx-auto px-4 py-8 max-w-3xl space-y-8">
      <div>
        <h1 className="text-3xl font-bold">Social Feed</h1>
        <p className="text-muted-foreground mt-2">Stay connected with the Biola sports community</p>
      </div>

      {/* Create Post */}
      <Card>
        <CardHeader>
          <CardTitle>Share an Update</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <Textarea
            placeholder="What's happening in your sports activities?"
            value={newPost}
            onChange={(e) => setNewPost(e.target.value)}
            className="min-h-[100px]"
          />
          <Button>Post Update</Button>
        </CardContent>
      </Card>

      {/* Activity Feed */}
      <div className="space-y-4">
        {activities.map((activity) => (
          <Card key={activity.id}>
            <CardContent className="pt-6">
              <div className="flex gap-4">
                <Avatar>
                  <AvatarFallback className="bg-gradient-to-br from-blue-500 to-indigo-500 text-white">
                    {activity.user.split(' ').map(n => n[0]).join('')}
                  </AvatarFallback>
                </Avatar>
                <div className="flex-1 space-y-3">
                  <div>
                    <p className="font-semibold">{activity.user}</p>
                    <p className="text-sm text-muted-foreground">
                      {activity.action}
                    </p>
                  </div>
                  <Card className="bg-accent/50">
                    <CardContent className="p-4 space-y-2">
                      <div className="flex items-center gap-2">
                        <Users className="size-4 text-primary" />
                        <span className="font-semibold">{activity.sport}</span>
                      </div>
                      <div className="flex items-center gap-2 text-sm text-muted-foreground">
                        <MapPin className="size-3" />
                        <span>{activity.facility}</span>
                      </div>
                    </CardContent>
                  </Card>
                  <div className="flex items-center gap-6 text-sm text-muted-foreground">
                    <button className="flex items-center gap-2 hover:text-red-500 transition-colors">
                      <Heart className="size-4" />
                      <span>{activity.likes}</span>
                    </button>
                    <button className="flex items-center gap-2 hover:text-blue-500 transition-colors">
                      <MessageCircle className="size-4" />
                      <span>{activity.comments}</span>
                    </button>
                    <button className="flex items-center gap-2 hover:text-green-500 transition-colors">
                      <Share2 className="size-4" />
                      <span>Share</span>
                    </button>
                    <span className="ml-auto text-xs">
                      {format(activity.time, 'MMM d, h:mm a')}
                    </span>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}
