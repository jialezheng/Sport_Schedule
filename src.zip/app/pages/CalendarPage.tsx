import { useState, useMemo } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { Badge } from '../components/ui/badge';
import { Button } from '../components/ui/button';
import { Calendar, Clock, MapPin, AlertCircle, ChevronLeft, ChevronRight, Trophy, Dumbbell, Wrench, Star, Users } from 'lucide-react';
import { format, addMonths, subMonths, startOfMonth, endOfMonth, eachDayOfInterval, isSameMonth, isSameDay, isToday, parseISO, isPast, isFuture } from 'date-fns';

// 25Live Event Type
interface Event25Live {
  id: string;
  title: string;
  facilityId: string;
  facilityName: string;
  startTime: string; // ISO format
  endTime: string; // ISO format
  eventType: 'practice' | 'game' | 'tournament' | 'maintenance' | 'special';
  organization: string;
  description?: string;
  status: 'confirmed' | 'tentative' | 'cancelled';
  affectsRecreational: boolean; // Whether this blocks recreational use
  attendees?: number;
}

// Mock 25Live Events Data - Based on typical Biola University athletic schedule
const mock25LiveEvents: Event25Live[] = [
  // Basketball Events at Chase Gymnasium
  {
    id: 'evt-001',
    title: 'Men\'s Basketball Practice',
    facilityId: 'fac-1',
    facilityName: 'Chase Gymnasium',
    startTime: '2026-03-26T06:00:00',
    endTime: '2026-03-26T08:00:00',
    eventType: 'practice',
    organization: 'Biola Men\'s Basketball',
    description: 'Team practice session - Full court reserved',
    status: 'confirmed',
    affectsRecreational: true,
    attendees: 18
  },
  {
    id: 'evt-002',
    title: 'Women\'s Basketball Game vs Azusa Pacific',
    facilityId: 'fac-1',
    facilityName: 'Chase Gymnasium',
    startTime: '2026-03-27T18:00:00',
    endTime: '2026-03-27T20:30:00',
    eventType: 'game',
    organization: 'Biola Women\'s Basketball',
    description: 'Home game - Facility completely unavailable for recreational use. Setup begins at 5:00 PM',
    status: 'confirmed',
    affectsRecreational: true,
    attendees: 250
  },
  {
    id: 'evt-003',
    title: 'Basketball Court Maintenance',
    facilityId: 'fac-1',
    facilityName: 'Chase Gymnasium',
    startTime: '2026-03-28T08:00:00',
    endTime: '2026-03-28T12:00:00',
    eventType: 'maintenance',
    organization: 'Facilities Management',
    description: 'Floor refinishing and line painting - Court will be slippery, no entry allowed',
    status: 'confirmed',
    affectsRecreational: true
  },
  
  // Soccer Events
  {
    id: 'evt-004',
    title: 'Men\'s Soccer Practice',
    facilityId: 'fac-2',
    facilityName: 'Soccer Field',
    startTime: '2026-03-26T15:00:00',
    endTime: '2026-03-26T17:00:00',
    eventType: 'practice',
    organization: 'Biola Men\'s Soccer',
    description: 'Full field practice with drills and scrimmage',
    status: 'confirmed',
    affectsRecreational: true,
    attendees: 25
  },
  {
    id: 'evt-005',
    title: 'Women\'s Soccer Game vs Vanguard',
    facilityId: 'fac-2',
    facilityName: 'Soccer Field',
    startTime: '2026-03-29T14:00:00',
    endTime: '2026-03-29T16:00:00',
    eventType: 'game',
    organization: 'Biola Women\'s Soccer',
    description: 'Conference game - Field closed from 12:00 PM for pre-game setup',
    status: 'confirmed',
    affectsRecreational: true,
    attendees: 180
  },
  {
    id: 'evt-006',
    title: 'Field Maintenance & Irrigation',
    facilityId: 'fac-2',
    facilityName: 'Soccer Field',
    startTime: '2026-03-30T06:00:00',
    endTime: '2026-03-30T09:00:00',
    eventType: 'maintenance',
    organization: 'Grounds Crew',
    description: 'Weekly field care - Mowing, line marking, and irrigation system check',
    status: 'confirmed',
    affectsRecreational: true
  },
  
  // Tennis Events
  {
    id: 'evt-007',
    title: 'Men\'s Tennis Match vs The Master\'s University',
    facilityId: 'fac-3',
    facilityName: 'Tennis Courts',
    startTime: '2026-03-27T10:00:00',
    endTime: '2026-03-27T14:00:00',
    eventType: 'game',
    organization: 'Biola Men\'s Tennis',
    description: 'All 6 courts reserved for dual match',
    status: 'confirmed',
    affectsRecreational: true,
    attendees: 50
  },
  {
    id: 'evt-008',
    title: 'Women\'s Tennis Practice',
    facilityId: 'fac-3',
    facilityName: 'Tennis Courts',
    startTime: '2026-03-28T15:00:00',
    endTime: '2026-03-28T17:00:00',
    eventType: 'practice',
    organization: 'Biola Women\'s Tennis',
    description: 'Courts 1-4 reserved for team practice',
    status: 'confirmed',
    affectsRecreational: true,
    attendees: 12
  },
  {
    id: 'evt-009',
    title: 'Court Resurfacing - Courts 1-3',
    facilityId: 'fac-3',
    facilityName: 'Tennis Courts',
    startTime: '2026-03-31T07:00:00',
    endTime: '2026-03-31T16:00:00',
    eventType: 'maintenance',
    organization: 'Facilities Management',
    description: 'Courts 1-3 unavailable for resurfacing. Courts 4-6 remain open for recreational use',
    status: 'confirmed',
    affectsRecreational: true
  },
  
  // Aquatic Center Events
  {
    id: 'evt-010',
    title: 'Swim Team Morning Practice',
    facilityId: 'fac-4',
    facilityName: 'Aquatic Center',
    startTime: '2026-03-26T05:30:00',
    endTime: '2026-03-26T07:00:00',
    eventType: 'practice',
    organization: 'Biola Swim & Dive Team',
    description: 'Early morning training session - 4 lanes reserved',
    status: 'confirmed',
    affectsRecreational: true,
    attendees: 20
  },
  {
    id: 'evt-011',
    title: 'Invitational Swim Meet',
    facilityId: 'fac-4',
    facilityName: 'Aquatic Center',
    startTime: '2026-03-29T08:00:00',
    endTime: '2026-03-29T18:00:00',
    eventType: 'tournament',
    organization: 'Biola Swim & Dive',
    description: 'All-day championship meet - Entire facility closed to recreational use',
    status: 'confirmed',
    affectsRecreational: true,
    attendees: 150
  },
  {
    id: 'evt-012',
    title: 'Pool Chemical Balance & Filter Cleaning',
    facilityId: 'fac-4',
    facilityName: 'Aquatic Center',
    startTime: '2026-04-01T06:00:00',
    endTime: '2026-04-01T10:00:00',
    eventType: 'maintenance',
    organization: 'Pool Services',
    description: 'Monthly deep cleaning and water chemistry adjustment',
    status: 'confirmed',
    affectsRecreational: true
  },
  
  // Track & Field Events
  {
    id: 'evt-013',
    title: 'Track & Field Practice',
    facilityId: 'fac-5',
    facilityName: 'Track & Field',
    startTime: '2026-03-26T14:00:00',
    endTime: '2026-03-26T17:00:00',
    eventType: 'practice',
    organization: 'Biola Track & Field',
    description: 'Full team workout - Track and field areas reserved',
    status: 'confirmed',
    affectsRecreational: true,
    attendees: 35
  },
  {
    id: 'evt-014',
    title: 'Spring Invitational Track Meet',
    facilityId: 'fac-5',
    facilityName: 'Track & Field',
    startTime: '2026-03-28T09:00:00',
    endTime: '2026-03-28T17:00:00',
    eventType: 'tournament',
    organization: 'Biola Track & Field',
    description: 'Multi-school championship event - Entire facility closed',
    status: 'confirmed',
    affectsRecreational: true,
    attendees: 300
  },
  {
    id: 'evt-015',
    title: 'Track Surface Inspection',
    facilityId: 'fac-5',
    facilityName: 'Track & Field',
    startTime: '2026-04-02T07:00:00',
    endTime: '2026-04-02T11:00:00',
    eventType: 'maintenance',
    organization: 'Facilities Management',
    description: 'Annual track surface safety inspection and repairs',
    status: 'confirmed',
    affectsRecreational: true
  },

  // Additional Basketball Events
  {
    id: 'evt-016',
    title: 'Men\'s Basketball Game vs Point Loma',
    facilityId: 'fac-1',
    facilityName: 'Chase Gymnasium',
    startTime: '2026-03-30T19:00:00',
    endTime: '2026-03-30T21:00:00',
    eventType: 'game',
    organization: 'Biola Men\'s Basketball',
    description: 'Conference rivalry game - High attendance expected',
    status: 'confirmed',
    affectsRecreational: true,
    attendees: 400
  },
  {
    id: 'evt-017',
    title: 'Intramural Basketball Tournament Finals',
    facilityId: 'fac-1',
    facilityName: 'Chase Gymnasium',
    startTime: '2026-04-05T10:00:00',
    endTime: '2026-04-05T16:00:00',
    eventType: 'tournament',
    organization: 'Student Life - Intramurals',
    description: 'Championship games for all divisions',
    status: 'confirmed',
    affectsRecreational: true,
    attendees: 120
  },

  // Future events
  {
    id: 'evt-018',
    title: 'Soccer Field Line Painting',
    facilityId: 'fac-2',
    facilityName: 'Soccer Field',
    startTime: '2026-04-07T06:00:00',
    endTime: '2026-04-07T09:00:00',
    eventType: 'maintenance',
    organization: 'Grounds Crew',
    description: 'Bi-weekly field marking - Wet paint, stay off grass',
    status: 'confirmed',
    affectsRecreational: true
  },
  {
    id: 'evt-019',
    title: 'Women\'s Soccer Practice',
    facilityId: 'fac-2',
    facilityName: 'Soccer Field',
    startTime: '2026-04-03T15:00:00',
    endTime: '2026-04-03T17:00:00',
    eventType: 'practice',
    organization: 'Biola Women\'s Soccer',
    description: 'Regular team training session',
    status: 'confirmed',
    affectsRecreational: true,
    attendees: 22
  },
  {
    id: 'evt-020',
    title: 'Spring Tennis Tournament',
    facilityId: 'fac-3',
    facilityName: 'Tennis Courts',
    startTime: '2026-04-04T08:00:00',
    endTime: '2026-04-04T18:00:00',
    eventType: 'tournament',
    organization: 'Biola Tennis Program',
    description: 'All courts reserved for tournament play',
    status: 'confirmed',
    affectsRecreational: true,
    attendees: 80
  },
];

export function CalendarPage() {
  const [currentDate, setCurrentDate] = useState(new Date());
  const [selectedDate, setSelectedDate] = useState<Date | null>(new Date());
  const [filterType, setFilterType] = useState<'all' | 'practice' | 'game' | 'tournament' | 'maintenance'>('all');
  const [filterFacility, setFilterFacility] = useState<'all' | string>('all');

  // Get days in current month
  const monthStart = startOfMonth(currentDate);
  const monthEnd = endOfMonth(currentDate);
  const daysInMonth = eachDayOfInterval({ start: monthStart, end: monthEnd });

  // Get unique facilities
  const facilities = useMemo(() => {
    const uniqueFacilities = Array.from(new Set(mock25LiveEvents.map(e => e.facilityName)));
    return uniqueFacilities.sort();
  }, []);

  // Filter events
  const filteredEvents = useMemo(() => {
    return mock25LiveEvents.filter(event => {
      if (filterType !== 'all' && event.eventType !== filterType) {
        return false;
      }
      if (filterFacility !== 'all' && event.facilityName !== filterFacility) {
        return false;
      }
      return true;
    });
  }, [filterType, filterFacility]);

  // Get events for selected date
  const selectedDateEvents = useMemo(() => {
    if (!selectedDate) return [];
    return filteredEvents.filter(event => {
      const eventDate = parseISO(event.startTime);
      return isSameDay(eventDate, selectedDate);
    }).sort((a, b) => parseISO(a.startTime).getTime() - parseISO(b.startTime).getTime());
  }, [selectedDate, filteredEvents]);

  // Get events for a specific day
  const getEventsForDay = (day: Date) => {
    return filteredEvents.filter(event => {
      const eventDate = parseISO(event.startTime);
      return isSameDay(eventDate, day);
    });
  };

  const handlePreviousMonth = () => {
    setCurrentDate(subMonths(currentDate, 1));
  };

  const handleNextMonth = () => {
    setCurrentDate(addMonths(currentDate, 1));
  };

  const getEventTypeColor = (type: string) => {
    switch (type) {
      case 'game':
        return 'bg-red-500';
      case 'practice':
        return 'bg-blue-500';
      case 'tournament':
        return 'bg-purple-500';
      case 'maintenance':
        return 'bg-orange-500';
      default:
        return 'bg-gray-500';
    }
  };

  const getEventTypeGradient = (type: string) => {
    switch (type) {
      case 'game':
        return 'from-red-500 to-red-600';
      case 'practice':
        return 'from-blue-500 to-blue-600';
      case 'tournament':
        return 'from-purple-500 to-purple-600';
      case 'maintenance':
        return 'from-orange-500 to-orange-600';
      default:
        return 'from-gray-500 to-gray-600';
    }
  };

  const getEventTypeIcon = (type: string) => {
    switch (type) {
      case 'game':
        return Trophy;
      case 'practice':
        return Dumbbell;
      case 'tournament':
        return Star;
      case 'maintenance':
        return Wrench;
      default:
        return Calendar;
    }
  };

  const getEventTypeBadgeVariant = (type: string): "default" | "secondary" | "destructive" | "outline" => {
    switch (type) {
      case 'game':
        return 'destructive';
      case 'tournament':
        return 'default';
      default:
        return 'secondary';
    }
  };

  return (
    <div className="container mx-auto px-4 py-8 space-y-8">
      {/* Header */}
      <div className="space-y-3">
        <div className="flex items-center gap-3">
          <div className="p-3 bg-gradient-to-br from-blue-600 to-indigo-600 rounded-xl shadow-lg">
            <Calendar className="size-8 text-white" />
          </div>
          <div>
            <h1 className="text-4xl font-bold">25Live Calendar</h1>
            <p className="text-lg text-muted-foreground mt-1">
              Official Biola University athletic events and facility schedules
            </p>
          </div>
        </div>
      </div>

      {/* Alert Banner */}
      <Card className="border-orange-500 bg-gradient-to-r from-orange-50 to-amber-50 dark:from-orange-950/20 dark:to-amber-950/20">
        <CardContent className="flex items-start gap-4 p-6">
          <div className="p-2 bg-orange-500 rounded-lg">
            <AlertCircle className="size-6 text-white" />
          </div>
          <div className="space-y-2 flex-1">
            <p className="font-semibold text-lg text-orange-900 dark:text-orange-200">
              These events block recreational facility use
            </p>
            <p className="text-orange-800 dark:text-orange-300">
              All events shown are confirmed athletic competitions, team practices, and scheduled maintenance from the Biola 25Live system. 
              You cannot make recreational reservations during these time blocks.
            </p>
          </div>
        </CardContent>
      </Card>

      {/* Filters */}
      <Card>
        <CardHeader>
          <CardTitle>Filter Events</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <label className="text-sm font-medium mb-2 block">Event Type</label>
            <div className="flex flex-wrap gap-2">
              <Button
                variant={filterType === 'all' ? 'default' : 'outline'}
                onClick={() => setFilterType('all')}
                className="gap-2"
              >
                All Events
              </Button>
              <Button
                variant={filterType === 'game' ? 'default' : 'outline'}
                onClick={() => setFilterType('game')}
                className="gap-2"
              >
                <Trophy className="size-4" />
                Games
              </Button>
              <Button
                variant={filterType === 'practice' ? 'default' : 'outline'}
                onClick={() => setFilterType('practice')}
                className="gap-2"
              >
                <Dumbbell className="size-4" />
                Practices
              </Button>
              <Button
                variant={filterType === 'tournament' ? 'default' : 'outline'}
                onClick={() => setFilterType('tournament')}
                className="gap-2"
              >
                <Star className="size-4" />
                Tournaments
              </Button>
              <Button
                variant={filterType === 'maintenance' ? 'default' : 'outline'}
                onClick={() => setFilterType('maintenance')}
                className="gap-2"
              >
                <Wrench className="size-4" />
                Maintenance
              </Button>
            </div>
          </div>

          <div>
            <label className="text-sm font-medium mb-2 block">Facility</label>
            <div className="flex flex-wrap gap-2">
              <Button
                variant={filterFacility === 'all' ? 'default' : 'outline'}
                size="sm"
                onClick={() => setFilterFacility('all')}
              >
                All Facilities
              </Button>
              {facilities.map(facility => (
                <Button
                  key={facility}
                  variant={filterFacility === facility ? 'default' : 'outline'}
                  size="sm"
                  onClick={() => setFilterFacility(facility)}
                >
                  {facility}
                </Button>
              ))}
            </div>
          </div>
        </CardContent>
      </Card>

      <div className="grid xl:grid-cols-[1fr,500px] gap-8">
        {/* Calendar View */}
        <Card className="shadow-lg">
          <CardHeader className="border-b bg-gradient-to-r from-blue-50 to-indigo-50 dark:from-blue-950/20 dark:to-indigo-950/20">
            <div className="flex items-center justify-between">
              <CardTitle className="text-2xl flex items-center gap-3">
                <Calendar className="size-6" />
                {format(currentDate, 'MMMM yyyy')}
              </CardTitle>
              <div className="flex gap-2">
                <Button variant="outline" onClick={handlePreviousMonth}>
                  <ChevronLeft className="size-5" />
                </Button>
                <Button 
                  variant="outline" 
                  onClick={() => {
                    setCurrentDate(new Date());
                    setSelectedDate(new Date());
                  }}
                >
                  Today
                </Button>
                <Button variant="outline" onClick={handleNextMonth}>
                  <ChevronRight className="size-5" />
                </Button>
              </div>
            </div>
          </CardHeader>
          <CardContent className="p-6">
            <div className="space-y-6">
              {/* Calendar Grid */}
              <div className="grid grid-cols-7 gap-2">
                {/* Day headers */}
                {['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'].map(day => (
                  <div key={day} className="text-center font-semibold text-sm text-muted-foreground py-3 border-b">
                    <span className="hidden md:inline">{day}</span>
                    <span className="md:hidden">{day.slice(0, 3)}</span>
                  </div>
                ))}
                
                {/* Empty cells for days before month starts */}
                {Array.from({ length: monthStart.getDay() }).map((_, i) => (
                  <div key={`empty-${i}`} className="aspect-square p-2" />
                ))}
                
                {/* Days */}
                {daysInMonth.map(day => {
                  const dayEvents = getEventsForDay(day);
                  const isSelected = selectedDate && isSameDay(day, selectedDate);
                  const isCurrentDay = isToday(day);
                  const dayIsPast = isPast(day) && !isToday(day);
                  
                  return (
                    <button
                      key={day.toISOString()}
                      onClick={() => setSelectedDate(day)}
                      className={`
                        aspect-square p-2 rounded-xl border-2 transition-all
                        ${isSelected ? 'bg-primary text-primary-foreground border-primary shadow-lg scale-105' : 'hover:bg-muted border-border hover:border-primary/50 hover:shadow-md'}
                        ${isCurrentDay ? 'ring-2 ring-primary ring-offset-2' : ''}
                        ${!isSameMonth(day, currentDate) ? 'opacity-30' : ''}
                        ${dayIsPast ? 'opacity-60' : ''}
                      `}
                    >
                      <div className="size-full flex flex-col items-center justify-start gap-1.5">
                        <span className={`text-base font-semibold ${isCurrentDay && !isSelected ? 'text-primary' : ''}`}>
                          {format(day, 'd')}
                        </span>
                        {dayEvents.length > 0 && (
                          <div className="flex flex-col gap-1 w-full">
                            {dayEvents.slice(0, 3).map((event, i) => {
                              const Icon = getEventTypeIcon(event.eventType);
                              return (
                                <div
                                  key={i}
                                  className={`w-full h-1 rounded-full bg-gradient-to-r ${getEventTypeGradient(event.eventType)}`}
                                  title={event.title}
                                />
                              );
                            })}
                            {dayEvents.length > 3 && (
                              <span className="text-xs font-medium opacity-70">+{dayEvents.length - 3}</span>
                            )}
                          </div>
                        )}
                      </div>
                    </button>
                  );
                })}
              </div>

              {/* Legend */}
              <div className="flex flex-wrap gap-4 pt-6 border-t">
                <div className="flex items-center gap-2">
                  <div className="flex items-center justify-center size-8 rounded-lg bg-gradient-to-r from-red-500 to-red-600">
                    <Trophy className="size-4 text-white" />
                  </div>
                  <span className="font-medium">Game</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="flex items-center justify-center size-8 rounded-lg bg-gradient-to-r from-blue-500 to-blue-600">
                    <Dumbbell className="size-4 text-white" />
                  </div>
                  <span className="font-medium">Practice</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="flex items-center justify-center size-8 rounded-lg bg-gradient-to-r from-purple-500 to-purple-600">
                    <Star className="size-4 text-white" />
                  </div>
                  <span className="font-medium">Tournament</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="flex items-center justify-center size-8 rounded-lg bg-gradient-to-r from-orange-500 to-orange-600">
                    <Wrench className="size-4 text-white" />
                  </div>
                  <span className="font-medium">Maintenance</span>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Events List for Selected Date */}
        <Card className="shadow-lg xl:sticky xl:top-24 xl:h-fit xl:max-h-[calc(100vh-7rem)]">
          <CardHeader className="border-b bg-muted/50">
            <CardTitle className="text-xl">
              {selectedDate ? (
                <div className="space-y-1">
                  <div className="text-2xl font-bold">
                    {format(selectedDate, 'EEEE')}
                  </div>
                  <div className="text-lg text-muted-foreground font-normal">
                    {format(selectedDate, 'MMMM d, yyyy')}
                  </div>
                </div>
              ) : (
                'Select a date'
              )}
            </CardTitle>
          </CardHeader>
          <CardContent className="p-0">
            {selectedDate ? (
              <div className="max-h-[600px] overflow-y-auto">
                {selectedDateEvents.length === 0 ? (
                  <div className="text-center py-16 px-6">
                    <div className="inline-flex items-center justify-center size-16 rounded-full bg-green-100 dark:bg-green-900/20 mb-4">
                      <Calendar className="size-8 text-green-600 dark:text-green-400" />
                    </div>
                    <p className="text-lg font-medium mb-2">No Events Scheduled</p>
                    <p className="text-muted-foreground">
                      This day is available for recreational reservations
                    </p>
                  </div>
                ) : (
                  <div className="divide-y">
                    {selectedDateEvents.map(event => {
                      const Icon = getEventTypeIcon(event.eventType);
                      return (
                        <div key={event.id} className="p-6 hover:bg-muted/30 transition-colors">
                          <div className="space-y-4">
                            {/* Header */}
                            <div className="flex items-start justify-between gap-3">
                              <div className="flex items-start gap-3 flex-1">
                                <div className={`p-2.5 rounded-xl bg-gradient-to-br ${getEventTypeGradient(event.eventType)} shadow-md`}>
                                  <Icon className="size-5 text-white" />
                                </div>
                                <div className="flex-1 min-w-0">
                                  <h4 className="font-bold text-lg leading-tight mb-1">{event.title}</h4>
                                  <p className="text-sm text-muted-foreground font-medium">{event.organization}</p>
                                </div>
                              </div>
                              <Badge variant={getEventTypeBadgeVariant(event.eventType)} className="capitalize">
                                {event.eventType}
                              </Badge>
                            </div>
                            
                            {/* Details */}
                            <div className="space-y-2.5 pl-12">
                              <div className="flex items-center gap-3">
                                <Clock className="size-4 text-muted-foreground flex-shrink-0" />
                                <span className="font-medium">
                                  {format(parseISO(event.startTime), 'h:mm a')} - {format(parseISO(event.endTime), 'h:mm a')}
                                </span>
                                <span className="text-sm text-muted-foreground">
                                  ({Math.round((parseISO(event.endTime).getTime() - parseISO(event.startTime).getTime()) / (1000 * 60 * 60) * 10) / 10} hours)
                                </span>
                              </div>
                              
                              <div className="flex items-center gap-3">
                                <MapPin className="size-4 text-muted-foreground flex-shrink-0" />
                                <span className="font-medium">{event.facilityName}</span>
                              </div>

                              {event.attendees && (
                                <div className="flex items-center gap-3">
                                  <Users className="size-4 text-muted-foreground flex-shrink-0" />
                                  <span>{event.attendees} expected attendees</span>
                                </div>
                              )}
                            </div>

                            {/* Description */}
                            {event.description && (
                              <div className="pl-12 pt-2 border-t">
                                <p className="text-sm leading-relaxed">{event.description}</p>
                              </div>
                            )}

                            {/* Recreational Impact */}
                            {event.affectsRecreational && (
                              <div className="pl-12">
                                <div className="inline-flex items-center gap-2 px-3 py-1.5 bg-orange-100 dark:bg-orange-900/20 text-orange-900 dark:text-orange-300 rounded-lg">
                                  <AlertCircle className="size-4" />
                                  <span className="text-sm font-medium">Blocks recreational use</span>
                                </div>
                              </div>
                            )}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
            ) : (
              <div className="text-center py-16 px-6">
                <Calendar className="size-16 mx-auto text-muted-foreground mb-4 opacity-50" />
                <p className="text-lg font-medium mb-2">Select a Date</p>
                <p className="text-muted-foreground">
                  Click on any date in the calendar to view scheduled events
                </p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Upcoming Events Timeline */}
      <Card className="shadow-lg">
        <CardHeader className="border-b bg-gradient-to-r from-purple-50 to-pink-50 dark:from-purple-950/20 dark:to-pink-950/20">
          <CardTitle className="text-2xl flex items-center gap-3">
            <Star className="size-6" />
            Upcoming Events Timeline
          </CardTitle>
        </CardHeader>
        <CardContent className="p-6">
          <div className="space-y-1 max-h-[500px] overflow-y-auto">
            {filteredEvents
              .filter(event => isFuture(parseISO(event.startTime)) || isToday(parseISO(event.startTime)))
              .sort((a, b) => parseISO(a.startTime).getTime() - parseISO(b.startTime).getTime())
              .slice(0, 20)
              .map((event, index) => {
                const Icon = getEventTypeIcon(event.eventType);
                return (
                  <div
                    key={event.id}
                    className="flex items-center gap-4 p-4 rounded-xl hover:bg-muted transition-all cursor-pointer group"
                    onClick={() => setSelectedDate(parseISO(event.startTime))}
                  >
                    <div className={`p-3 rounded-xl bg-gradient-to-br ${getEventTypeGradient(event.eventType)} shadow-md group-hover:shadow-lg transition-shadow`}>
                      <Icon className="size-5 text-white" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="font-semibold text-lg truncate group-hover:text-primary transition-colors">{event.title}</p>
                      <div className="flex items-center gap-3 mt-1">
                        <p className="text-sm text-muted-foreground">{event.facilityName}</p>
                        <span className="text-xs text-muted-foreground">•</span>
                        <Badge variant="outline" className="text-xs">
                          {event.eventType}
                        </Badge>
                      </div>
                    </div>
                    <div className="text-right flex-shrink-0">
                      <p className="font-semibold text-sm">{format(parseISO(event.startTime), 'MMM d')}</p>
                      <p className="text-sm text-muted-foreground">{format(parseISO(event.startTime), 'h:mm a')}</p>
                    </div>
                  </div>
                );
              })}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}