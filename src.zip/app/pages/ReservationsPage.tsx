import { useState, useMemo } from 'react';
import { mockTimeSlots, mockFacilities } from '../data/mockData';
import { TimeSlot } from '../types';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { Button } from '../components/ui/button';
import { Badge } from '../components/ui/badge';
import { Calendar, Clock, Users, MapPin } from 'lucide-react';
import { Link } from 'react-router';
import { formatTimeRange } from '../utils/timeFormat';
import { format } from 'date-fns';

export function ReservationsPage() {
  const [timeSlots] = useState<TimeSlot[]>(mockTimeSlots);

  const myReservations = useMemo(() => {
    // Show all reservations for demo purposes
    return timeSlots.sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());
  }, [timeSlots]);

  const upcomingReservations = myReservations.filter(slot => {
    const slotDateTime = new Date(`${slot.date}T${slot.startTime}`);
    return slotDateTime > new Date();
  });

  const pastReservations = myReservations.filter(slot => {
    const slotDateTime = new Date(`${slot.date}T${slot.startTime}`);
    return slotDateTime <= new Date();
  });

  return (
    <div className="container mx-auto px-4 py-8 space-y-8">
      <div>
        <h1 className="text-3xl font-bold">My Reservations</h1>
        <p className="text-muted-foreground mt-2">Manage your upcoming and past sessions</p>
      </div>

      {/* Upcoming */}
      <div className="space-y-4">
        <h2 className="text-2xl font-semibold">Upcoming Sessions</h2>
        {upcomingReservations.length > 0 ? (
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {upcomingReservations.map((slot) => {
              const facility = mockFacilities.find(f => f.id === slot.facilityId);
              if (!facility) return null;

              const isFull = slot.currentParticipants >= slot.capacity;
              const date = new Date(slot.date + 'T00:00:00');

              return (
                <Card key={slot.id} className="hover:shadow-lg transition-shadow">
                  <CardHeader>
                    <div className="flex items-start justify-between">
                      <div>
                        <CardTitle className="text-lg">{slot.sport}</CardTitle>
                        <p className="text-sm text-muted-foreground">{facility.name}</p>
                      </div>
                      {isFull && <Badge variant="secondary">Full</Badge>}
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <div className="flex items-center gap-2 text-sm">
                      <Calendar className="size-4 text-primary" />
                      <span>{format(date, 'EEEE, MMM d, yyyy')}</span>
                    </div>
                    <div className="flex items-center gap-2 text-sm">
                      <Clock className="size-4 text-primary" />
                      <span>{formatTimeRange(slot.startTime, slot.endTime)}</span>
                    </div>
                    <div className="flex items-center gap-2 text-sm">
                      <Users className="size-4 text-primary" />
                      <span>{slot.currentParticipants}/{slot.capacity} participants</span>
                    </div>
                    <div className="flex items-center gap-2 text-sm">
                      <MapPin className="size-4 text-primary" />
                      <span className="text-xs">{facility.location}</span>
                    </div>
                    <Link to={`/facility/${facility.id}`}>
                      <Button variant="outline" size="sm" className="w-full mt-2">
                        View Details
                      </Button>
                    </Link>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        ) : (
          <Card>
            <CardContent className="py-12 text-center">
              <Calendar className="size-12 text-muted-foreground mx-auto mb-4" />
              <h3 className="text-lg font-semibold mb-2">No Upcoming Reservations</h3>
              <p className="text-muted-foreground mb-4">You haven't joined any sessions yet</p>
              <Link to="/">
                <Button>Browse Facilities</Button>
              </Link>
            </CardContent>
          </Card>
        )}
      </div>

      {/* Past */}
      {pastReservations.length > 0 && (
        <div className="space-y-4">
          <h2 className="text-2xl font-semibold">Past Sessions</h2>
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {pastReservations.map((slot) => {
              const facility = mockFacilities.find(f => f.id === slot.facilityId);
              if (!facility) return null;

              const date = new Date(slot.date + 'T00:00:00');

              return (
                <Card key={slot.id} className="opacity-75">
                  <CardHeader>
                    <CardTitle className="text-lg">{slot.sport}</CardTitle>
                    <p className="text-sm text-muted-foreground">{facility.name}</p>
                  </CardHeader>
                  <CardContent className="space-y-2">
                    <div className="flex items-center gap-2 text-sm">
                      <Calendar className="size-4 text-muted-foreground" />
                      <span>{format(date, 'MMM d, yyyy')}</span>
                    </div>
                    <div className="flex items-center gap-2 text-sm">
                      <Clock className="size-4 text-muted-foreground" />
                      <span>{formatTimeRange(slot.startTime, slot.endTime)}</span>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
}
