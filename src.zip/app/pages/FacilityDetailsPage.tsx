import { useState, useMemo } from 'react';
import { useParams, useNavigate } from 'react-router';
import { mockFacilities, mockTimeSlots } from '../data/mockData';
import { FacilityDetails } from '../components/FacilityDetails';
import { ChatDialog } from '../components/ChatDialog';
import { TimeSlot, Message } from '../types';
import { toast } from 'sonner';
import { addDistanceAndETA } from '../utils/distanceCalculator';

export function FacilityDetailsPage() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const [timeSlots, setTimeSlots] = useState<TimeSlot[]>(mockTimeSlots);
  const [messages, setMessages] = useState<Message[]>([]);
  const [chatTimeSlotId, setChatTimeSlotId] = useState<string | null>(null);
  
  // Generate a temporary user ID for guest users
  const guestUserId = 'guest-user';
  const guestUserName = 'Guest User';

  // Add distance and ETA to facilities
  const facilitiesWithDistance = useMemo(() => addDistanceAndETA(mockFacilities), []);
  const facility = facilitiesWithDistance.find(f => f.id === id);
  const facilityTimeSlots = timeSlots.filter(ts => ts.facilityId === id);
  const selectedChatTimeSlot = timeSlots.find(ts => ts.id === chatTimeSlotId);
  const chatMessages = messages.filter(m => m.timeSlotId === chatTimeSlotId);

  if (!facility) {
    return (
      <div className="container mx-auto px-4 py-8 text-center">
        <h1 className="text-2xl font-bold">Facility not found</h1>
        <button onClick={() => navigate('/')} className="mt-4 text-primary hover:underline">
          Go back to dashboard
        </button>
      </div>
    );
  }

  const handleJoinTimeSlot = (timeSlotId: string) => {
    setTimeSlots(prev => prev.map(ts => {
      if (ts.id === timeSlotId) {
        if (ts.participants.some(p => p.id === guestUserId)) {
          toast.error('You have already joined this session');
          return ts;
        }
        if (ts.currentParticipants >= ts.capacity) {
          toast.error('This session is full');
          return ts;
        }
        toast.success('Successfully joined the session!');
        return {
          ...ts,
          currentParticipants: ts.currentParticipants + 1,
          participants: [
            ...ts.participants,
            {
              id: guestUserId,
              name: guestUserName,
              joinedAt: new Date().toISOString(),
            }
          ]
        };
      }
      return ts;
    }));
  };

  const handleViewChat = (timeSlotId: string) => {
    setChatTimeSlotId(timeSlotId);
  };

  const handleSendMessage = (message: string) => {
    if (!chatTimeSlotId) return;
    
    const newMessage: Message = {
      id: `msg-${Date.now()}`,
      timeSlotId: chatTimeSlotId,
      userId: guestUserId,
      userName: guestUserName,
      message,
      timestamp: new Date().toISOString(),
    };

    setMessages(prev => [...prev, newMessage]);
  };

  const handleCreateReservation = (data: {
    name: string;
    email: string;
    phone: string;
    sport: string;
    date: string;
    startTime: string;
    endTime: string;
    capacity: number;
  }) => {
    const newTimeSlot: TimeSlot = {
      id: `slot-${Date.now()}`,
      facilityId: id!,
      sport: data.sport,
      date: data.date,
      startTime: data.startTime,
      endTime: data.endTime,
      capacity: data.capacity,
      currentParticipants: 1,
      participants: [
        {
          id: `user-${Date.now()}`,
          name: data.name,
          joinedAt: new Date().toISOString(),
        }
      ],
      createdBy: `user-${Date.now()}`,
    };

    setTimeSlots(prev => [...prev, newTimeSlot]);
    toast.success(`Reservation created successfully! Confirmation sent to ${data.email}`);
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <FacilityDetails
        facility={facility}
        timeSlots={facilityTimeSlots}
        onBack={() => navigate('/')}
        onJoinTimeSlot={handleJoinTimeSlot}
        onViewChat={handleViewChat}
        onCreateReservation={handleCreateReservation}
        currentUserId={guestUserId}
      />

      {selectedChatTimeSlot && (
        <ChatDialog
          open={chatTimeSlotId !== null}
          onOpenChange={(open) => !open && setChatTimeSlotId(null)}
          timeSlot={selectedChatTimeSlot}
          messages={chatMessages}
          currentUserId={guestUserId}
          currentUserName={guestUserName}
          onSendMessage={handleSendMessage}
        />
      )}
    </div>
  );
}