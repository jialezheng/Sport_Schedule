import { useState } from 'react';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Card, CardContent } from './ui/card';
import { ArrowLeft, MapPin, Plus, Clock, Car, Info, Accessibility, Navigation, PersonStanding } from 'lucide-react';
import { Facility, TimeSlot } from '../types';
import { TimeSlotCard } from './TimeSlotCard';
import { CreateReservationDialog } from './CreateReservationDialog';
import { formatTo12Hour } from '../utils/timeFormat';

interface FacilityDetailsProps {
  facility: Facility;
  timeSlots: TimeSlot[];
  onBack: () => void;
  onJoinTimeSlot: (timeSlotId: string) => void;
  onViewChat: (timeSlotId: string) => void;
  onCreateReservation: (data: {
    name: string;
    email: string;
    phone: string;
    sport: string;
    date: string;
    startTime: string;
    endTime: string;
    capacity: number;
  }) => void;
  currentUserId: string;
}

export function FacilityDetails({
  facility,
  timeSlots,
  onBack,
  onJoinTimeSlot,
  onViewChat,
  onCreateReservation,
  currentUserId,
}: FacilityDetailsProps) {
  const [createDialogOpen, setCreateDialogOpen] = useState(false);
  const [selectedTab, setSelectedTab] = useState('upcoming');

  const now = new Date();
  const upcomingSlots = timeSlots.filter(slot => {
    const slotDateTime = new Date(`${slot.date}T${slot.startTime}`);
    return slotDateTime > now;
  });

  const pastSlots = timeSlots.filter(slot => {
    const slotDateTime = new Date(`${slot.date}T${slot.startTime}`);
    return slotDateTime <= now;
  });

  return (
    <div className="space-y-6">
      <Button variant="ghost" onClick={onBack} className="mb-4">
        <ArrowLeft className="size-4 mr-2" />
        Back to Facilities
      </Button>

      <div className="relative">
        <img
          src={facility.image}
          alt={facility.name}
          className="w-full h-64 object-cover rounded-lg"
        />
        <Badge 
          variant={facility.type === 'campus' ? 'default' : 'secondary'}
          className="absolute top-4 right-4"
        >
          {facility.type === 'campus' ? 'Campus Facility' : 'Public Park'}
        </Badge>
      </div>

      <div>
        <h1 className="mb-2">{facility.name}</h1>
        <div className="flex items-start gap-2 text-muted-foreground mb-4">
          <MapPin className="size-5 mt-0.5 flex-shrink-0" />
          <span>{facility.location}</span>
        </div>
        <div className="flex flex-wrap gap-2 mb-4">
          {facility.sports.map((sport) => (
            <Badge key={sport} variant="outline">
              {sport}
            </Badge>
          ))}
        </div>
      </div>

      {/* Facility Information Cards */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        {/* Distance and ETA Card */}
        {(facility.distance !== undefined || facility.drivingETA !== undefined || facility.walkingETA !== undefined) && (
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-start gap-3">
                <Navigation className="size-5 text-primary mt-0.5 flex-shrink-0" />
                <div className="flex-1">
                  <h3 className="font-semibold mb-3">Distance & ETA</h3>
                  <div className="space-y-2 text-sm">
                    {facility.distance !== undefined && (
                      <div className="flex items-center justify-between">
                        <span className="text-muted-foreground">Distance:</span>
                        <span className="font-medium">{facility.distance} miles</span>
                      </div>
                    )}
                    {facility.drivingETA !== undefined && (
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-1.5">
                          <Car className="size-4 text-blue-600" />
                          <span className="text-muted-foreground">Driving:</span>
                        </div>
                        <span className="font-medium">{facility.drivingETA} min</span>
                      </div>
                    )}
                    {facility.walkingETA !== undefined && (
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-1.5">
                          <PersonStanding className="size-4 text-green-600" />
                          <span className="text-muted-foreground">Walking:</span>
                        </div>
                        <span className="font-medium">{facility.walkingETA} min</span>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-start gap-3">
              <Info className="size-5 text-primary mt-0.5 flex-shrink-0" />
              <div>
                <h3 className="font-semibold mb-2">About</h3>
                <p className="text-sm text-muted-foreground">{facility.description}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-start gap-3">
              <Clock className="size-5 text-primary mt-0.5 flex-shrink-0" />
              <div>
                <h3 className="font-semibold mb-2">Hours</h3>
                <div className="text-sm space-y-1">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Opens:</span>
                    <span className="font-medium">{formatTo12Hour(facility.openingTime)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Closes:</span>
                    <span className="font-medium">{formatTo12Hour(facility.closingTime)}</span>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-start gap-3">
              <Car className="size-5 text-primary mt-0.5 flex-shrink-0" />
              <div>
                <h3 className="font-semibold mb-2">Parking</h3>
                <p className="text-sm text-muted-foreground">
                  {facility.parkingAvailable ? 'Free parking available on-site' : 'Limited street parking'}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="md:col-span-2">
          <CardContent className="pt-6">
            <div className="flex items-start gap-3">
              <Accessibility className="size-5 text-primary mt-0.5 flex-shrink-0" />
              <div>
                <h3 className="font-semibold mb-2">Accessibility</h3>
                <p className="text-sm text-muted-foreground">{facility.accessibility}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <h3 className="font-semibold mb-3">Amenities</h3>
            <div className="flex flex-wrap gap-1.5">
              {facility.amenities.map((amenity) => (
                <Badge key={amenity} variant="secondary" className="text-xs">
                  {amenity}
                </Badge>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="flex items-center justify-between">
        <h2>Reservations</h2>
        <Button onClick={() => setCreateDialogOpen(true)}>
          <Plus className="size-4 mr-2" />
          Create Reservation
        </Button>
      </div>

      <Tabs value={selectedTab} onValueChange={setSelectedTab}>
        <TabsList className="grid w-full max-w-md grid-cols-2">
          <TabsTrigger value="upcoming">
            Upcoming ({upcomingSlots.length})
          </TabsTrigger>
          <TabsTrigger value="past">
            Past ({pastSlots.length})
          </TabsTrigger>
        </TabsList>

        <TabsContent value="upcoming" className="space-y-4 mt-6">
          {upcomingSlots.length === 0 ? (
            <div className="text-center py-12 text-muted-foreground">
              No upcoming reservations. Create one to get started!
            </div>
          ) : (
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
              {upcomingSlots.map((slot) => {
                const isParticipant = slot.participants.some(
                  (p) => p.id === currentUserId
                );
                return (
                  <TimeSlotCard
                    key={slot.id}
                    timeSlot={slot}
                    facility={facility}
                    onJoin={() => onJoinTimeSlot(slot.id)}
                    onViewChat={() => onViewChat(slot.id)}
                    isParticipant={isParticipant}
                    currentUserId={currentUserId}
                  />
                );
              })}
            </div>
          )}
        </TabsContent>

        <TabsContent value="past" className="space-y-4 mt-6">
          {pastSlots.length === 0 ? (
            <div className="text-center py-12 text-muted-foreground">
              No past reservations.
            </div>
          ) : (
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
              {pastSlots.map((slot) => {
                const isParticipant = slot.participants.some(
                  (p) => p.id === currentUserId
                );
                return (
                  <TimeSlotCard
                    key={slot.id}
                    timeSlot={slot}
                    facility={facility}
                    onJoin={() => onJoinTimeSlot(slot.id)}
                    onViewChat={() => onViewChat(slot.id)}
                    isParticipant={isParticipant}
                    currentUserId={currentUserId}
                  />
                );
              })}
            </div>
          )}
        </TabsContent>
      </Tabs>

      <CreateReservationDialog
        open={createDialogOpen}
        onOpenChange={setCreateDialogOpen}
        facility={facility}
        onCreateReservation={onCreateReservation}
      />
    </div>
  );
}