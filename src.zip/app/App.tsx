import { RouterProvider } from 'react-router';
import { ThemeProvider } from './components/ThemeProvider';
import { Toaster } from './components/ui/sonner';
import { router } from './router';

export default function App() {
  return (
    <ThemeProvider defaultTheme="light" storageKey="biola-sports-theme">
      <Toaster />
      <RouterProvider router={router} />
    </ThemeProvider>
  );
}
